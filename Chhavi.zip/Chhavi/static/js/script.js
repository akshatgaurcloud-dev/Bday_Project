const giftButton = document.getElementById('giftButton');
const buttonLabel = document.getElementById('buttonLabel');
const giftCards = document.querySelectorAll('.gift-card');
const envelopeCards = document.querySelectorAll('.envelope-card');
const envelopeTriggers = document.querySelectorAll('.envelope-trigger');
const letterModal = document.getElementById('letterModal');
const closeModal = document.getElementById('closeModal');
const modalSeal = document.getElementById('modalSeal');
const modalTitle = document.getElementById('modalTitle');
const modalMessage = document.getElementById('modalMessage');
const modalVideo = document.getElementById('modalVideo');
const burstLayer = document.getElementById('burstLayer');
const partyPopper = document.querySelector('.party-popper');
const burstColors = ['#e27c85', '#e6b84e', '#91b9a7', '#d68aa2', '#f29b62'];
let letterRequestId = 0;

function burstPartyPopper() {
  if (!partyPopper || partyPopper.offsetParent === null) return;
  const layerBounds = burstLayer.getBoundingClientRect();
  const popperBounds = partyPopper.getBoundingClientRect();
  const originX = popperBounds.left + popperBounds.width * 0.46 - layerBounds.left;
  const originY = popperBounds.top + popperBounds.height * 0.2 - layerBounds.top;
  for (let index = 0; index < 15; index += 1) {
    const piece = document.createElement('span');
    const angle = (-Math.PI * 0.92) + (Math.random() * Math.PI * 0.62);
    const distance = 80 + Math.random() * 110;
    piece.className = 'burst-piece';
    piece.style.left = `${originX}px`;
    piece.style.top = `${originY}px`;
    piece.style.setProperty('--burst-color', burstColors[index % burstColors.length]);
    piece.style.setProperty('--burst-x', `${Math.cos(angle) * distance}px`);
    piece.style.setProperty('--burst-y', `${Math.sin(angle) * distance}px`);
    piece.style.setProperty('--burst-rotation', `${Math.random() * 420 - 210}deg`);
    piece.style.animationDelay = `${Math.random() * 180}ms`;
    piece.addEventListener('animationend', () => piece.remove(), { once: true });
    burstLayer.appendChild(piece);
  }
}

function closeLetterModal() {
  letterModal.classList.add('hidden');
  letterModal.classList.remove('flex');
  document.body.classList.remove('overflow-hidden');
  modalVideo.pause();
  modalVideo.removeAttribute('src');
  modalVideo.load();
}

async function openLetterModal(card) {
  const content = card.querySelector('.envelope-content');
  const requestId = ++letterRequestId;
  modalSeal.textContent = card.querySelector('.envelope-seal').textContent;
  modalTitle.textContent = card.querySelector('.text-sm').textContent;
  modalMessage.textContent = 'Opening your letter...';
  try {
    const letterPath = card.dataset.letter.replace(/^letters\//, '');
    const response = await fetch(`/letters/${letterPath}`);
    if (!response.ok) throw new Error('Letter could not be loaded');
    const letterText = await response.text();
    if (requestId === letterRequestId) modalMessage.textContent = letterText;
  } catch (error) {
    if (requestId === letterRequestId) modalMessage.textContent = content.querySelector('p').textContent;
  }
  modalVideo.src = `/static/${card.dataset.video}`;
  modalVideo.load();
  letterModal.classList.remove('hidden');
  letterModal.classList.add('flex');
  document.body.classList.add('overflow-hidden');
  closeModal.focus();
}

envelopeTriggers.forEach((trigger) => trigger.addEventListener('click', () => openLetterModal(trigger.closest('.envelope-card'))));
closeModal.addEventListener('click', closeLetterModal);
letterModal.addEventListener('click', (event) => { if (event.target === letterModal) closeLetterModal(); });
document.addEventListener('keydown', (event) => { if (event.key === 'Escape' && !letterModal.classList.contains('hidden')) closeLetterModal(); });
giftButton.addEventListener('click', () => {
  const isRevealed = giftButton.dataset.revealed === 'true';
  giftButton.dataset.revealed = String(!isRevealed);
  buttonLabel.textContent = isRevealed ? 'Click here to view your gifts' : 'Your gifts are here!';
  giftButton.querySelector('span:last-child').textContent = isRevealed ? '→' : '♥';
  giftButton.classList.add('pop');
  setTimeout(() => giftButton.classList.remove('pop'), 450);
  envelopeCards.forEach((card) => card.classList.toggle('revealed', !isRevealed));
  giftCards.forEach((card) => card.classList.toggle('revealed', !isRevealed));
  if (isRevealed) closeLetterModal();
});

burstPartyPopper();
setInterval(burstPartyPopper, 2800);
