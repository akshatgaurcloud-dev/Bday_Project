Add your video files here using these exact names:

akshat.mp4
khushi.mp4
kiran.mp4
yug.mp4
nandini.mp4
ellis.mp4
rohit.mp4
mom.mp4
dad.mp4
brother.mp4

The birthday page uses these local paths for each envelope gift.
