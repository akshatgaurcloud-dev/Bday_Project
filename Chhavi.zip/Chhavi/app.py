import os
from pathlib import Path

from flask import Flask, render_template, send_from_directory

app = Flask(__name__)
LETTERS_DIR = Path(__file__).parent / "letters"


@app.get("/")
def home():
    return render_template("index.html")


@app.get("/letters/<path:filename>")
def letter(filename):
    return send_from_directory(LETTERS_DIR, filename)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5001"))
    app.run(debug=True, port=port)
